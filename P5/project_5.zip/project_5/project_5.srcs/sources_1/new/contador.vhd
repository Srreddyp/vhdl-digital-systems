
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity contador is
    port(
        rst_global : in std_logic;
        rst : in std_logic;
        clk : in std_logic;
        enable : in std_logic;
        count : in std_logic;
        salida : out std_logic_vector(3 downto 0)
    );
end contador;

architecture Behavioral of contador is
    
    signal contActual,contSiguiente : std_logic_vector(3 downto 0);

begin
    
    SYNC: process(clk, rst, rst_global, contSiguiente)
	begin
		if rising_edge(clk) then
			if rst = '1' or rst_global = '1' then
				contActual <= (others => '0');
			else
				contActual <= contSiguiente;
			end if;
		end if;
	end process SYNC;
	
	COMB: process(enable, count, contActual, contSiguiente)
	begin
	    contSiguiente <= contActual;
		if enable = '1' and count = '1' then
		      if(contActual = "1001") then
		          contSiguiente <= (others => '0');
		      else
		          contSiguiente <= contActual + 1;
		      end if;
		end if;
	end process COMB;

    salida <= contActual;

end Behavioral;
