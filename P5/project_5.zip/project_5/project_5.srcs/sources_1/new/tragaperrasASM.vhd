
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity tragaperrasASM is
    port(
        rst : in std_logic;
        clk : in std_logic;
        inicio : in std_logic;
        fin : in std_logic;
        leds : out std_logic_vector(15 downto 0);
        display : out std_logic_vector(6 downto 0);
        display_enable : out std_logic_vector(3 downto 0)          
        );
end tragaperrasASM;

architecture Behavioral of tragaperrasASM is

    type tipo_estado is (s0, s1, s2, s3, s4);
    signal estadoActual, estadoSiguiente : tipo_estado;
    signal inicio2: std_logic;
    signal fin2: std_logic;
    signal cuenta_medio_segundo
,cuenta_display1,cuenta_display2: std_logic;
    signal enable_contador_display1, enable_contador_display2,enable_contador_5 : std_logic;
    signal salida_cont1,salida_cont2, salida_cont5 : std_logic_vector(3 downto 0);
    signal rst1,rst2,rst5 : std_logic;
    signal op_code : std_logic_vector(2 downto 0);
    signal zeros : std_logic_vector(3 downto 0);
    
    component debouncer 
      PORT (
        rst: IN std_logic;
        clk: IN std_logic;
        x: IN std_logic;
        xDeb: OUT std_logic;
        xDebFallingEdge: OUT std_logic;
        xDebRisingEdge: OUT std_logic
      );
    END component;
    
    component divisor 
        port (
            rst: in STD_LOGIC;
            clk: in STD_LOGIC; -- reloj de entrada de la entity superior
            cuenta_medio_segundo: out STD_LOGIC;
            cuenta_display1: out STD_LOGIC;
            cuenta_display2: out STD_LOGIC
        );
    end component;
    
    component efectosLEDs 
      Port (
        rst             : IN  std_logic;
        clk             : IN  std_logic;
        opCode          : IN  std_logic_vector(2 downto 0);
        LEDs            : OUT std_logic_vector(15 downto 0)   
      );
    end component;
    
    component displays 
        Port ( 
            rst : in STD_LOGIC;
            clk : in STD_LOGIC;       
            digito_0 : in  STD_LOGIC_VECTOR (3 downto 0);
            digito_1 : in  STD_LOGIC_VECTOR (3 downto 0);
            digito_2 : in  STD_LOGIC_VECTOR (3 downto 0);
            digito_3 : in  STD_LOGIC_VECTOR (3 downto 0);
            display : out  STD_LOGIC_VECTOR (6 downto 0);
            display_enable : out  STD_LOGIC_VECTOR (3 downto 0)
         );
    end component;
    
    component contador 
        port(
            rst_global : in std_logic;
            rst : in std_logic;
            clk : in std_logic;
            enable : in std_logic;
            count : in std_logic;
            salida : out std_logic_vector(3 downto 0)
        );
    end component;
    
    
begin
    zeros <= (others => '0');
    mod_debouncer1: debouncer port map(rst,clk,inicio,open,open,inicio2);
    mod_debouncer2: debouncer port map(rst,clk,fin,open,open,fin2);
    mod_divisor: divisor port map(rst,clk,cuenta_medio_segundo,cuenta_display1,cuenta_display2);
    mod_contador_display1: contador port map(rst, rst1, clk, enable_contador_display1, cuenta_display1,salida_cont1); 
    mod_contador_display2: contador port map(rst, rst2, clk, enable_contador_display2, cuenta_display2,salida_cont2); 
    mod_contador_display5: contador port map(rst, rst5, clk, enable_contador_5, cuenta_medio_segundo,salida_cont5); 
    mod_efectosLEDs : efectosLEDs port map(rst,clk, op_code, leds);
    mod_displays : displays port map(rst,clk,salida_cont1, salida_cont2, zeros,zeros ,display,display_enable);
    
    SYNC: process(clk, rst)
	begin
		if rising_edge(clk) then
			if rst = '1' then
				estadoActual <= s0;
			else
				estadoActual <= estadoSiguiente;
			end if;
		end if;
	end process SYNC;
	
	COMB: process(estadoActual, inicio2, fin2,salida_cont1,salida_cont2,salida_cont5)
	begin
	
		estadoSiguiente <= estadoActual;
		enable_contador_display1 <= '0';
		enable_contador_display2 <= '0';
		enable_contador_5 <= '0';
		rst1 <= '0';
		rst2 <= '0';
		rst5 <= '0';
		op_code <= "000";
        
		case estadoActual is
	
			when s0 =>
			    op_code <= "100";
			    rst1 <= '1';
			    rst2 <= '1';
				if inicio2 = '1' then
				    estadoSiguiente <= s1;
				end if;
				
			when s1 =>
			
			     enable_contador_display1 <= '1';
		         enable_contador_display2 <= '1';	
			     rst5 <= '1';
			     if fin2 = '1' then
			         estadoSiguiente <= s2;
			     end if;
			
			when s2 =>
			     if salida_cont1 = salida_cont2 then
			         estadoSiguiente <= s3;
			     else 
			         estadoSiguiente <= s4;
			     end if;
			when s3 =>
			     
			     op_code <= "010";
			     enable_contador_5 <= '1';
			     if salida_cont5 = "1001" then
			         estadoSiguiente <= s0;
			     end if;
			when s4 =>
			     
			     op_code <= "011";
			     enable_contador_5 <= '1';
			     if salida_cont5 = "1001" then
			         estadoSiguiente <= s0;
			     end if;
			
		end case;
	end process COMB;

    
end Behavioral;
