----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 01.11.2023 17:20:40
-- Design Name: 
-- Module Name: red_iterativa_comparadores - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity red_iterativa_comparadores is
    generic (
        num_bits : natural := 4;
        num_entradas : natural := 4
    );
    
    port (
        X : in std_logic_vector(num_entradas*num_bits-1 downto 0);
        S : out std_logic_vector(num_bits-1 downto 0)
    );
end red_iterativa_comparadores;

architecture Behavioral of red_iterativa_comparadores is
    component celda 
        generic(
            num_bits : natural := 4
        );
        port (
            x : in std_logic_vector(num_bits-1 downto 0);
            c_in : in std_logic_vector(num_bits-1 downto 0);
            c_out : out std_logic_vector(num_bits-1 downto 0)
        );
    end component;
    
    signal C : std_logic_vector(num_entradas*num_bits-1 downto 0);
    
begin
    gen1: for i in 1 to num_entradas-1 generate
        u: celda generic map(num_bits)
                 port map(X(num_bits*(i+1)-1 downto num_bits*i),C(num_bits*i-1 downto num_bits*(i-1)),C(num_bits*(i+1)-1 downto num_bits*i));
    end generate gen1;
    C(num_bits-1 downto 0) <= X(num_bits-1 downto 0); 
    S <= C(num_bits*num_entradas-1 downto num_bits*(num_entradas-1));
end Behavioral;
