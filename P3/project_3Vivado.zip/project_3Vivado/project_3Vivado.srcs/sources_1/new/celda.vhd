----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 01.11.2023 17:24:52
-- Design Name: 
-- Module Name: celda - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity celda is
    generic(
        num_bits : natural := 4
    );
    port (
        x : in std_logic_vector(num_bits-1 downto 0);
        c_in : in std_logic_vector(num_bits-1 downto 0);
        c_out : out std_logic_vector(num_bits-1 downto 0)
    );
end celda;

architecture Behavioral of celda is
    
begin
    c_out <= x when signed(x) > signed(c_in) else c_in;

end Behavioral;
