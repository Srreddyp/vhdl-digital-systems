library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity cerrojo is
    port (
        rst: in std_logic;
        clk: in std_logic;
        boton: in std_logic;
        num_intentos: in std_logic_vector(3 downto 0);
        clave: in std_logic_vector(7 downto 0);
        intentos: out std_logic_vector(6 downto 0);
        leds: out std_logic_vector(15 downto 0);
        an: out std_logic_vector(3 downto 0)
     );
end cerrojo;

architecture Behavioral of cerrojo is
    
    type tipo_estado is (inicial, cerrado, final);
    signal estadoActual, estadoSiguiente: tipo_estado;
    --signal estadoNumero: std_logic_vector(3 downto 0);
    signal boton2: std_logic;
    signal clave_final: std_logic_vector(7 downto 0);
    signal clave_siguiente: std_logic_vector(7 downto 0);
    signal op_leds: std_logic_vector(2 downto 0);
    signal contador: std_logic_vector(3 downto 0);
    signal contadorSiguiente: std_logic_vector(3 downto 0);
    
    component conv_7seg 
    Port ( x : in  STD_LOGIC_VECTOR (3 downto 0);
           display : out  STD_LOGIC_VECTOR (6 downto 0));
    end component;
    
    component debouncer 
        PORT (
            rst: IN std_logic;
            clk: IN std_logic;
            x: IN std_logic;
            xDeb: OUT std_logic;
            xDebFallingEdge: OUT std_logic;
            xDebRisingEdge: OUT std_logic
        );
    END component;
    
    component efectosLEDs 
      Port (
        rst             : IN  std_logic;
        clk             : IN  std_logic;
        opCode          : IN  std_logic_vector(2 downto 0);
        LEDs            : OUT std_logic_vector(15 downto 0)   
      );
    end component;
    
    
begin
    an <= "1110";
    mod_conv: conv_7seg port map(contador,intentos);
    mod_debouncer: debouncer port map(rst,clk,boton,open,open,boton2);
    mod_efectosLEDs: efectosLEDs port map(rst,clk,op_leds,leds);
    
    SYNC: process(clk, rst)
	begin
	   --if rst = '1' then
			--	estadoActual <= inicial;
		--elsif rising_edge(clk) then
			--	estadoActual <= estadoSiguiente;
		--end if;
		if rising_edge(clk) then
			if rst = '1' then
				estadoActual <= inicial;
				contador <= (others => '0');
				clave_final <= (others => '0');
			else
				estadoActual <= estadoSiguiente;
				contador <= contadorSiguiente;
				clave_final <= clave_siguiente;
			end if;
		end if;
	end process SYNC;
	
	COMB: process(estadoActual, boton2, clave,clave_final,contador,num_intentos,contadorSiguiente)
	begin
	
		estadoSiguiente <= estadoActual;
		contadorSiguiente <= contador;
		clave_siguiente <= clave_final;
		op_leds <= "000";
		--estadoNumero <= "0000";
        
		case estadoActual is
		
			when inicial =>
			    op_leds <= "001";
				if (boton2 = '1' and num_intentos /= "0000") then
					estadoSiguiente <= cerrado;
					clave_siguiente <= clave;
					contadorSiguiente <= num_intentos;
					
				end if;
				
			when cerrado =>
				if (boton2 = '1') then
					if(clave = clave_final) then
					   estadoSiguiente <= inicial;
					   contadorSiguiente <= (others =>'0');
					else 
					   contadorSiguiente <= contador-1;
					   if(contadorSiguiente = "0000") then
					       estadoSiguiente <= final;
					   end if;
				    end if;
				end if;			
			
			
			when final =>
			    op_leds <= "010";
			 
			
		end case;
	end process COMB;


end Behavioral;
