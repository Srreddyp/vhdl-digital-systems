
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity multiplicadorASM is
    port (
        rst             : in  std_logic;
        clk             : in  std_logic;
        A               : in  std_logic_vector(3 downto 0);
        B               : in  std_logic_vector(3 downto 0);
        inicio          : in  std_logic;
        R               : out std_logic_vector(7 downto 0);
        fin             : out std_logic;
        display : out  STD_LOGIC_VECTOR (6 downto 0);
        display_enable : out  STD_LOGIC_VECTOR (3 downto 0) --preguntar
  );
end multiplicadorASM;

architecture Behavioral of multiplicadorASM is
    type tipo_estado is (s0, s1, s2,s3);
    signal estadoActual, estadoSiguiente: tipo_estado;
    signal inicio2: std_logic;
    signal rActual, rSiguiente: std_logic_vector(7 downto 0);
    signal aActual, aSiguiente: std_logic_vector(3 downto 0);
    signal nActual, nSiguiente: std_logic_vector(3 downto 0);
    
    component displays 
        Port ( 
            rst : in STD_LOGIC;
            clk : in STD_LOGIC;       
            digito_0 : in  STD_LOGIC_VECTOR (3 downto 0);
            digito_1 : in  STD_LOGIC_VECTOR (3 downto 0);
            digito_2 : in  STD_LOGIC_VECTOR (3 downto 0);
            digito_3 : in  STD_LOGIC_VECTOR (3 downto 0);
            display : out  STD_LOGIC_VECTOR (6 downto 0);
            display_enable : out  STD_LOGIC_VECTOR (3 downto 0)
         );
    end component;
    
    component debouncer 
        PORT (
            rst: IN std_logic;
            clk: IN std_logic;
            x: IN std_logic;
            xDeb: OUT std_logic;
            xDebFallingEdge: OUT std_logic;
            xDebRisingEdge: OUT std_logic
        );
    END component;
    
    
    
begin
    mod_displays: displays port map(rst,clk,rActual(3 downto 0),rActual(7 downto 4),rActual(3 downto 0),rActual(7 downto 4), display, display_enable);
    mod_debouncer: debouncer port map(rst,clk,inicio,open,open,inicio2); --preguntar entradas display
    
    SYNC: process(clk, rst)
	begin
		if rising_edge(clk) then
			if rst = '1' then
				estadoActual <= s0;
				rActual <= (others => '0');
				aActual <= (others => '0');
				nActual <= (others => '0');
			else
				estadoActual <= estadoSiguiente;
				rActual <= rSiguiente;
				aActual <= aSiguiente;
				nActual <= nSiguiente;
			end if;
		end if;
	end process SYNC;
	
	COMB: process(estadoActual, inicio2,rActual,nActual,A,B,aActual)
	begin
	
		estadoSiguiente <= estadoActual;
		rSiguiente <= rActual;
		aSiguiente <= aActual;
		nSiguiente <= nActual;
		fin <= '0';
		R <= rActual; --preguntar
        
		case estadoActual is
		
			when s0 =>
			    fin <= '1';
				if (inicio2 = '1') then
					estadoSiguiente <= s1;					
				end if;
				
			when s1 =>
				nSiguiente <= B;
				aSiguiente <= A;
				rSiguiente <= (others => '0');	
				estadoSiguiente <= s2;	
			when s2 =>
			    if(unsigned(nActual) = 0) then
			         estadoSiguiente <= s0;
			    else
			         estadoSiguiente <= s3;
			    end if;
			when s3 =>
			     rSiguiente <= std_logic_vector(unsigned(rActual) + unsigned(aActual));
			     nSiguiente <= std_logic_vector(unsigned(nActual) - 1); 
			     estadoSiguiente <= s2;
		end case;
	end process COMB;



end Behavioral;
