
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;


entity comparador is
    port(
        A : in std_logic_vector(15 downto 0);
        B : in std_logic_vector(15 downto 0);
        salida : out std_logic
    );
end comparador;

architecture Behavioral of comparador is

begin
    salida <= '1' when A = B else '0';

end Behavioral;
